Go to the subdir

~/PACKAGES/LIGGGHTS/LIGGGHTS-PUBLIC/examples/LIGGGHTS/Tutorials_public/

and play with the examples.  Be carefull with lpp, sometimes you need
to run it directly instead of using the postscript script
