This directory contains example files created by Emilien Azema.  You
should also see the full examples directory at
/home/vagrant/PACKAGES/LMGC90/lmgc90_user/examples/

Also, check the jupyter notebooks inside the examples notebooks.
