rm -rf example/*
