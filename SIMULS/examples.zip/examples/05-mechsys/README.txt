Go to the directory ~/PACKAGES/MECHSYS/msys_tutorial and there run
every example marked as test_XXXXX . Follow the instructions at
http://mechsys.nongnu.org/installtut.html .

