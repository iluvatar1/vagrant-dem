Go to the directory
~/PACKAGES/MERCURYDPM/MercuryDPM/MercuryBuild/Drivers/MercurySimpleDemos
and run the executables without extension and for visualization the
ones ended in .xballs .

