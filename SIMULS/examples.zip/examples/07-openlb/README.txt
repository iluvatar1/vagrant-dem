Go to PACKAGES/OPENLB/olb-1.0r0/examples/ and play. 
