cd ./1Creacion
rm -f pari posi
cd ../2Mezcla/input
rm -f pari posi
cd ../display
rm -f *
cd ../output
rm -f *
cd ../../3Densificacion/input
rm -f pari posi
cd ../display
rm -f *
cd ../output
rm -f *
cd ../../4Corte/input
rm -f pari posi
cd ../display
rm -f *
cd ../output
rm -f *
cd ../postpro
rm -f *

