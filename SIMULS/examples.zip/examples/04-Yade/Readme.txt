Execute yade on the terminal, and then press F12 to start playing with
the examples.  As usual, read the docs and go to the web for more
information.
